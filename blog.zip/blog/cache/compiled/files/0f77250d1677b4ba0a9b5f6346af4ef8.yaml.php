<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/Users/andre.matiazzo/Desktop/mtzz/github/matiazzo.github.io/blog/grav-admin/user/config/security.yaml',
    'modified' => 1491864374,
    'data' => [
        'salt' => 'tRUaeiLEl415xq'
    ]
];
