<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/Users/andre.matiazzo/Desktop/mtzz/github/matiazzo.github.io/blog/grav-admin/system/languages/el.yaml',
    'modified' => 1490964276,
    'data' => [
        'MONTHS_OF_THE_YEAR' => [
            0 => 'Ιανουάριος',
            1 => 'Φεβρουάριος',
            2 => 'Μάρτιος',
            3 => 'Απρίλιος',
            4 => 'Μάιος',
            5 => 'Ιούνιος',
            6 => 'Ιούλιος',
            7 => 'Αύγουστος',
            8 => 'Σεπτέμβριος',
            9 => 'Οκτώβριος',
            10 => 'Νοέμβριος',
            11 => 'Δεκέμβριος'
        ],
        'DAYS_OF_THE_WEEK' => [
            0 => 'Δευτέρα',
            1 => 'Τρίτη',
            2 => 'Τετάρτη',
            3 => 'Πέμπτη',
            4 => 'Παρασκευή',
            5 => 'Σάββατο',
            6 => 'Κυριακή'
        ]
    ]
];
