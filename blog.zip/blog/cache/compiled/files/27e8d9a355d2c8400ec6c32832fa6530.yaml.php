<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/Users/andre.matiazzo/Desktop/mtzz/github/matiazzo.github.io/blog/grav-admin/user/plugins/admin/languages/tlh.yaml',
    'modified' => 1490964276,
    'data' => [
        'PLUGIN_ADMIN' => [
            'LOGIN_BTN_FORGOT' => 'lIj',
            'BACK' => 'chap',
            'NORMAL' => 'motlh',
            'YES' => 'HIja\'',
            'NO' => 'Qo\'',
            'DISABLED' => 'Qotlh'
        ]
    ]
];
