<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'themes://antimatter/antimatter.yaml',
    'modified' => 1490964276,
    'data' => [
        'enabled' => true,
        'dropdown' => [
            'enabled' => false
        ]
    ]
];
