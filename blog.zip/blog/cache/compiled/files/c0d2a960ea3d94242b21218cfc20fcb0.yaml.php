<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/Users/andre.matiazzo/Desktop/mtzz/github/matiazzo.github.io/blog/grav-admin/user/plugins/problems/problems.yaml',
    'modified' => 1490964276,
    'data' => [
        'enabled' => true,
        'built_in_css' => true
    ]
];
